package com.gonet.test.model;

public class Rating {
	
	private String Source;
    private String Value;
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getValue() {
		return Value;
	}
	public void setValue(String value) {
		Value = value;
	}
	@Override
	public String toString() {
		return "Rating [Source=" + Source + ", Value=" + Value + "]";
	}
	
}
