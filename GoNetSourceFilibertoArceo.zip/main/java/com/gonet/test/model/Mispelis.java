package com.gonet.test.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="mispelis")
public class Mispelis {
  public String mi_puntuacion;
  public String fecha_vista;
  public String mis_comentarios;
  @Id
  public String imdbID;
public String getMi_puntuacion() {
	return mi_puntuacion;
}
public void setMi_puntuacion(String mi_puntuacion) {
	this.mi_puntuacion = mi_puntuacion;
}
public String getFecha_vista() {
	return fecha_vista;
}
public void setFecha_vista(String fecha_vista) {
	this.fecha_vista = fecha_vista;
}
public String getMis_comentarios() {
	return mis_comentarios;
}
public void setMis_comentarios(String mis_comentarios) {
	this.mis_comentarios = mis_comentarios;
}
public String getImdbID() {
	return imdbID;
}
public void setImdbID(String imdbID) {
	this.imdbID = imdbID;
}
@Override
public String toString() {
	return "Mispelis [mi_puntuacion=" + mi_puntuacion + ", fecha_vista=" + fecha_vista + ", mis_comentarios="
			+ mis_comentarios + ", imdbID=" + imdbID + "]";
}

}
