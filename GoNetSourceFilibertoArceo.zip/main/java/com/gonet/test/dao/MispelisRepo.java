package com.gonet.test.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gonet.test.model.Mispelis;

//Repositorio JPA
public interface MispelisRepo extends JpaRepository <Mispelis, String> {

}
