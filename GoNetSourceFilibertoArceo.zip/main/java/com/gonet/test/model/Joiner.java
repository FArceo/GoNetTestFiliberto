package com.gonet.test.model;

import java.util.Optional;

public class Joiner {
	
	private Omdb omdb;
    private Optional<Mispelis> mispelis;
  
	public Omdb getOmdb() {
		return omdb;
	}
	public void setOmdb(Omdb omdb) {
		this.omdb = omdb;
	}
	public Optional<Mispelis> getMispelis() {
		return mispelis;
	}
	public void setMispelis(Optional<Mispelis> mispelis) {
		this.mispelis = mispelis;
	}


	@Override
	public String toString() {
		return "Joiner [omdb=" + omdb + ", mispelis=" + mispelis + "]";
	}  
    
}
