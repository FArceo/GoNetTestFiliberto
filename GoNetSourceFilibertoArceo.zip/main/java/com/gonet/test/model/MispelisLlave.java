package com.gonet.test.model;

public class MispelisLlave {
	private Mispelis mispelis;
	private String llave;
	public Mispelis getMispelis() {
		return mispelis;
	}
	public void setMispelis(Mispelis mispelis) {
		this.mispelis = mispelis;
	}
	public String getLlave() {
		return llave;
	}
	public void setLlave(String llave) {
		this.llave = llave;
	}
	@Override
	public String toString() {
		return "MispelisLlave [mispelis=" + mispelis + ", llave=" + llave + "]";
	}

}
