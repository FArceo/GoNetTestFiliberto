INSERT INTO gonet.aut (id, llave, pass, usr) VALUES (0, 'NA', 'pass1', 'usr1');
INSERT INTO gonet.aut (id, llave, pass, usr) VALUES (1, 'NA', 'pass2', 'usr2');