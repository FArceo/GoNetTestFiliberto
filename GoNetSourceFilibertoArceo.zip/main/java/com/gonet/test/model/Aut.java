package com.gonet.test.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="aut")
public class Aut {

	private int id;
	@Id
	private String usr;
	private String pass;
	private String llave;

	
    private static final String ALPHA_NUMERIC_STRING = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	
    /* Esta funcion genera una llave aleatoria para usarse en la autenticación y autorización del uso de los servicios */
    public String generaLlave() {
    	int count=10; // Need a 10 character string;
    	StringBuilder builder = new StringBuilder();
    	while (count-- != 0) {
    	int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());//Math.random retuns a value between 0 and 1. That's why the minimum is 0 and the maximum is 62 (the string length - 1)
    	builder.append(ALPHA_NUMERIC_STRING.charAt(character));
    	}
    	return builder.toString();
    }
    
    /* Constructors                      */
	public Aut() {
		this.llave=generaLlave();
	}
	
	public Aut(int id, String usr, String pass, String llave) {
		this.id = id;
		this.usr = usr;
		this.pass = pass;
		this.llave = llave;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsr() {
		return usr;
	}
	public void setUsr(String usr) {
		this.usr = usr;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getLlave() {
		return llave;
	}
	public void setLlave(String llave) {
		if ( llave.isEmpty() ) {
			this.llave=generaLlave();
		}
		else {
		   this.llave = llave;
		}
	}


	@Override
	public String toString() {
		return "Aut [id=" + id + ", usr=" + usr + ", pass=" + pass + ", llave=" + llave + "]";
	}

}
