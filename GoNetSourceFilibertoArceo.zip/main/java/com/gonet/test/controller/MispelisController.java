package com.gonet.test.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.gonet.test.dao.AutRepo;
import com.gonet.test.dao.MispelisRepo;
import com.gonet.test.model.Aut;
import com.gonet.test.model.Joiner;
import com.gonet.test.model.Mispelis;
import com.gonet.test.model.MispelisLlave;
import com.gonet.test.model.Omdb;
import com.google.gson.Gson;

@RestController
public class MispelisController {

	@Autowired
	MispelisRepo repo;
	
	@Autowired
	AutRepo arepo;
	
	@Value("${llave.api}")
	private  String apiKey; // Mi llave objtenida en www.omdbapi.com
	
	@Autowired
	private RestTemplate restTemplate;	
	
	
	//  Autenticación y autoriza
	@PostMapping(path="/auth", consumes= {"application/json"})
		public Aut AA(@RequestBody Aut aut) { //Autentica y autoriza

		Aut nuevo = new Aut();
		nuevo=arepo.autenticaUsuario(aut.getUsr(), aut.getPass());
		if (nuevo==null) {
			return new Aut(0,"","","Invalido");
		}
		nuevo.setLlave(aut.generaLlave());
		arepo.save(nuevo);
		return nuevo;
	}
	
	@RequestMapping(path="/auth/{llave}", produces= {"application/json"})
	@ResponseBody
	public Aut getKey(@PathVariable("llave") String llave) { //Autentica y autoriza
    Aut resultado=arepo.getByLlave(llave);
	    return resultado;
     }

	@RequestMapping(path="/pelis/{id}/{llave}", produces={"application/json"} )
	@ResponseBody	
	public Omdb getMovieInfo(@PathVariable("id") String id, @PathVariable("llave") String llave) { 
		// Recibe como parámetro del id de la película y regresa un objeto tipo Omdb.
		Aut aa=arepo.getByLlave(llave);
		Omdb omdb=new Omdb();
		if (aa==null) {
			return omdb;
		}
		
		String url="http://www.omdbapi.com/?i="+id+"&apikey="+apiKey;
		System.out.println(url);
		String omdbString = restTemplate.getForObject(url, String.class);
		System.out.println(omdbString);
		omdb = new Gson().fromJson(omdbString, Omdb.class);

		return omdb;
	}
	
	@RequestMapping(path="/pelisName/{name}/{llave}", produces={"application/json"} )
	@ResponseBody	
	public Omdb getMovieByName(@PathVariable("name") String name, @PathVariable("llave") String llave) { 
		// Recibe como parámetro el nombre de la pelicula y regresa un objeto tipo Omdb.
		Aut aa=arepo.getByLlave(llave);
		Omdb omdb=new Omdb();
		if (aa==null) {
			return omdb;
		}
		String url="http://www.omdbapi.com/?t="+name+"&apikey="+apiKey;
		System.out.println(url);
		String omdbString = restTemplate.getForObject(url, String.class);
		System.out.println(omdbString);
		omdb = new Gson().fromJson(omdbString, Omdb.class);

		return omdb;
	}
	
	@RequestMapping(path="/mispelis/{llave}", produces={"application/json"} )
	@ResponseBody		
	public List<Mispelis> getPelis(@PathVariable("llave") String llave)
	{	
		Aut aa=arepo.getByLlave(llave);
	    if (aa==null) {
	       return  null;
	    }
		return repo.findAll();  // Busca todas mis peliculas
	}
	
	@RequestMapping(path="/mispelis/{id}/{llave}", produces={"application/json"} )
	@ResponseBody		
	public Optional<Mispelis> getPelisById(@PathVariable("id") String id,@PathVariable("llave") String llave)
	{
		Aut aa=arepo.getByLlave(llave);
	    if (aa==null) {
	       return  null;
	    }
		return repo.findById(id);  //Encuentra mis peliculas por Id de película
	}
	
	//  Alta de una película.
	@PostMapping(path="/mispelisAdd", consumes= {"application/json"})
	public Mispelis addPelis(@RequestBody MispelisLlave mispelisLlave) { 
		Aut aa=arepo.getByLlave(mispelisLlave.getLlave());
	    if (aa==null) {
	       return  null;
	    }	
		repo.save(mispelisLlave.getMispelis());  //Da de alta mis películas
		return mispelisLlave.getMispelis();
	}

	
	//Borrado de una película
	@DeleteMapping("/mispslisDelete/{id}/{llave}")
	public String deleteMispelis(@PathVariable("id") String id,@PathVariable("llave") String llave) {
		Aut aa=arepo.getByLlave(llave);
	    if (aa==null) {
	       return  null;
	    }
		Mispelis mispelis = new Mispelis();			
		mispelis = repo.getOne(id);  //asigna el indice enviado aunque no exista alien
		repo.delete(mispelis);
		return "Borrado OK";
	}
	
	//  Actualiza un película
	@PutMapping(path="/mispelisUpdate", consumes= {"application/json"})
	public Mispelis updateMispelis(@RequestBody MispelisLlave mispelisLlave) { 
		Aut aa=arepo.getByLlave(mispelisLlave.getLlave());
	    if (aa==null) {
	       return  null;
	    }
		repo.save(mispelisLlave.getMispelis());
		return mispelisLlave.getMispelis();
	}
	
	/*Requerimiento de juntar el CORS + el sitio http://www.omdbapi.com se implementa consulta por titulo y por id */
	
	@RequestMapping(path="/joinName/{name}/{llave}", produces={"application/json"} )
	@ResponseBody	
	public Joiner getJoinByName(@PathVariable("name") String name,@PathVariable("llave") String llave) { 
		// Recibe como parámetro el nombre de la pelicula y regresa un objeto tipo Omdb.
		Aut aa=arepo.getByLlave(llave);
	    if (aa==null) {
	       return  null;
	    }
		Joiner joiner=new Joiner();
		Omdb omdb = new Omdb();

		String url="http://www.omdbapi.com/?t="+name+"&apikey="+apiKey;
		System.out.println(url);
		String omdbString = restTemplate.getForObject(url, String.class);
		System.out.println(omdbString);
		omdb = new Gson().fromJson(omdbString, Omdb.class);
		Optional<Mispelis> mispelis=getPelisById(omdb.getImdbID(),llave);
		joiner.setMispelis(mispelis);
		joiner.setOmdb(omdb);
		
		return joiner;
	}
	
	@RequestMapping(path="/joinId/{id}/{llave}", produces={"application/json"} )
	@ResponseBody	
	public Joiner getJoinById(@PathVariable("id") String id,@PathVariable("llave") String llave) { 
		// Recibe como parámetro el nombre de la pelicula y regresa un objeto tipo Omdb.
		Aut aa=arepo.getByLlave(llave);
	    if (aa==null) {
	       return  null;
	    }
		Joiner joiner=new Joiner();
		Omdb omdb = new Omdb();
		String url="http://www.omdbapi.com/?i="+id+"&apikey="+apiKey;
		System.out.println(url);
		String omdbString = restTemplate.getForObject(url, String.class);
		System.out.println(omdbString);
		omdb=getMovieInfo(id,llave);
		Optional<Mispelis> mispelis=getPelisById(id,llave);
	    joiner.setOmdb(omdb);
	    joiner.setMispelis(mispelis);

		return joiner;
	}
		
}// Fin de la clase
