package com.gonet.test.dao;

//import java.util.List;

//import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.gonet.test.model.Aut;

public interface AutRepo extends JpaRepository<Aut, Integer> {
	
	 @Query("select new Aut( a.id,a.usr,a.pass,a.llave ) from Aut a where a.usr like ?1 and a.pass like ?2")
	 Aut autenticaUsuario(String usr, String pass);

	 @Query("select new Aut( a.id,a.usr,a.pass,a.llave ) from Aut a where a.llave like ?1")
	 Aut getByLlave(String llave);
	 
}


